# DNS Lookup Service - Agent Core Runtime Deployment

## For Agent Core Runtime Compatibility

This package creates a **multi-architecture container** that works with Agent Core Runtime environments.

### Deploy Commands:
```bash
tar -xzf dns-lookup-agent-runtime-*.tar.gz
cd dns-lookup-agent-runtime-*
chmod +x deploy-multiarch.sh
./deploy-multiarch.sh v1.0.0
```

### What This Does:
✅ **Multi-architecture build** (ARM64 + x86_64)
✅ **Agent Core Runtime compatible**
✅ **Automatic platform detection**
✅ **ECR deployment ready**

### Image Output:
- **Single image URI** that works on any platform
- **Automatic platform selection** by container runtime
- **Compatible with all agent runtimes**

### Container Features:
- HTTP API on port 8080
- Health checks at `/health`
- DNS lookup at `/lookup?domain=example.com`
- Non-root security hardening
- Minimal attack surface

### Usage in Agent Runtime:
The container will automatically run on the correct architecture (ARM64 or x86_64) based on the agent runtime environment.

Image URI format: `{account}.dkr.ecr.{region}.amazonaws.com/dns-lookup-service:v1.0.0`
