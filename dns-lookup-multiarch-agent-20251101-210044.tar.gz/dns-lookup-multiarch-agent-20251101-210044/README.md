# DNS Lookup Service - Multi-Architecture Agent Core Runtime

## Universal Platform Support
✅ **ARM64** (AWS Graviton, Apple Silicon)
✅ **x86_64** (Intel/AMD processors)
✅ **Single image URI** works on both platforms
✅ **Automatic platform detection** by container runtime

## Deploy Commands:
```bash
tar -xzf dns-lookup-multiarch-agent-*.tar.gz
cd dns-lookup-multiarch-agent-*
chmod +x deploy.sh
./deploy.sh
```

## Features:
- **Multi-architecture manifest** (ARM64 + x86_64)
- **Lambda handler** for Agent Core Runtime
- **Multiple input format support**
- **Comprehensive error handling**
- **Health check endpoints**

## Test Inputs After Deploy:

### Basic Domain Lookup:
```json
{"domain": "google.com"}
```

### Query String Format:
```json
{"queryStringParameters": {"domain": "aws.amazon.com"}}
```

### HTTP Request Format:
```json
{
  "httpMethod": "GET",
  "path": "/lookup",
  "queryStringParameters": {"domain": "github.com"}
}
```

### Health Check:
```json
{"path": "/health"}
```

## Expected Output:
```json
{
  "statusCode": 200,
  "body": {
    "domain": "google.com",
    "records": [
      {"type": "A", "value": "142.250.180.14"}
    ],
    "status": "success",
    "timestamp": "2025-11-01T21:00:00Z"
  }
}
```

## Architecture Benefits:
- **Universal compatibility** - works on any Agent Core Runtime
- **Performance optimized** for each architecture
- **Future-proof** - supports new platforms automatically
- **Single deployment** - no platform-specific builds needed

## Image Details:
- **Repository**: dns-lookup-service
- **Tag**: v1.2.0
- **Platforms**: linux/amd64, linux/arm64
- **Entry Point**: lambda_handler.lambda_handler
