#!/bin/bash
# Verify multi-architecture deployment

REPO_NAME="dns-lookup-service"
VERSION_TAG="v1.2.0"
REGION=${AWS_DEFAULT_REGION:-"us-east-1"}
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
IMAGE_URI="${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${REPO_NAME}:${VERSION_TAG}"

echo "🔍 Verifying Multi-Architecture Deployment..."
echo "Image: $IMAGE_URI"
echo ""

# Check image manifest
echo "📋 Image Manifest:"
docker manifest inspect $IMAGE_URI 2>/dev/null || echo "❌ Manifest inspection failed"

echo ""
echo "✅ Deployment verification completed"
