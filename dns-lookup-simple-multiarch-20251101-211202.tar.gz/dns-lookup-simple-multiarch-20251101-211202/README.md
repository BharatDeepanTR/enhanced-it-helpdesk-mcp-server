# DNS Lookup Service - Simplified Multi-Architecture

## Cloud Shell Compatible Build
✅ **Avoids QEMU emulation issues**
✅ **Simplified Dockerfile** (no complex operations)
✅ **Retry logic** for multi-arch builds
✅ **Fallback to single architecture** if needed

## Deploy Commands:
```bash
tar -xzf dns-lookup-simple-multiarch-*.tar.gz
cd dns-lookup-simple-multiarch-*
chmod +x deploy.sh
./deploy.sh
```

## Build Strategy:
1. **Attempt multi-arch** (ARM64 + x86_64)
2. **Retry on failure** with clean builder
3. **Fallback to x86_64** if multi-arch fails
4. **Always produces working image**

## Test Inputs:

### Basic Domain Lookup:
```json
{"domain": "google.com"}
```

### Multiple Formats Supported:
```json
{"queryStringParameters": {"domain": "aws.amazon.com"}}
```

## Expected Output:
```json
{
  "statusCode": 200,
  "body": {
    "domain": "google.com",
    "records": [{"type": "A", "value": "142.250.180.14"}],
    "status": "success"
  }
}
```

## Fallback Behavior:
- If multi-arch fails → builds x86_64 only
- x86_64 images work on most Agent Core Runtime platforms
- Still provides full DNS lookup functionality
