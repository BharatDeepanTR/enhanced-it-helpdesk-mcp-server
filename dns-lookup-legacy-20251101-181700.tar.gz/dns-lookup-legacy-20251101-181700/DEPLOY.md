# Cloud Shell Deployment - Legacy Docker Mode

## Commands to Run:
```bash
tar -xzf dns-lookup-legacy-*.tar.gz
cd dns-lookup-legacy-*
chmod +x deploy-legacy.sh
./deploy-legacy.sh v1.0.0
```

## What This Does:
- Disables Docker BuildKit completely
- Uses legacy Docker build process
- Bypasses cache corruption issues
- Creates ARM64-compatible container

## Expected Output:
✅ Repository created/verified
✅ Docker login successful  
✅ Build completed (legacy mode)
✅ Push completed

Your image will be ready for ECS/EKS deployment!
