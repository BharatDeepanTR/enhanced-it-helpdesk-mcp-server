# DNS Lookup Service - Cloud Shell Deployment

## Quick Deploy to ECR

1. Extract: `tar -xzf dns-lookup-arm64-fixed-*.tar.gz && cd dns-lookup-arm64-fixed-*`
2. Deploy: `chmod +x deploy.sh && ./deploy.sh v1.0.0`

## What's Included
- Python service files (Lex functionality removed)
- ARM64 optimized Dockerfile (fixed image references)
- ECR deployment script
- Security-hardened container configuration

## Requirements
- Cloud Shell environment
- AWS credentials (auto-configured in Cloud Shell)
- Docker with BuildKit support (pre-installed)
