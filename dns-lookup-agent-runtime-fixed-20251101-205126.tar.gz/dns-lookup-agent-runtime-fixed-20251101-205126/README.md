# DNS Lookup Service - Agent Core Runtime Compatible

## Deploy Commands:
```bash
tar -xzf dns-lookup-agent-runtime-fixed-*.tar.gz
cd dns-lookup-agent-runtime-fixed-*
chmod +x update-agent-runtime.sh
./update-agent-runtime.sh
```

## What's Included:
✅ Lambda handler for Agent Core Runtime compatibility
✅ Updated Dockerfile with correct entry point
✅ All original DNS lookup functionality
✅ Multi-format input support

## Test Input After Deploy:
```json
{"domain": "google.com"}
```

## Expected Output:
```json
{
  "statusCode": 200,
  "body": {
    "domain": "google.com",
    "records": [{"type": "A", "value": "142.250.180.14"}],
    "status": "success"
  }
}
```
