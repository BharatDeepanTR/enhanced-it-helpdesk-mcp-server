# DNS Lookup Service - Cloud Shell (Simple Deploy)

## Fixed Cache Issue Deploy

1. Extract: `tar -xzf dns-lookup-cloudshell-simple-*.tar.gz && cd dns-lookup-cloudshell-simple-*`
2. Deploy: `chmod +x deploy-simple.sh && ./deploy-simple.sh v1.0.0`

This version bypasses Docker cache issues in Cloud Shell.
