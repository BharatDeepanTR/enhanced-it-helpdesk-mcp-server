# MCP-Compatible Application Details Lambda Deployment Package

This package contains the MCP-compatible version of the application details Lambda function that resolves the "internal error" issue with Agent Core Gateway.

## Package Contents

- `lambda_function.py` - Main Lambda handler with MCP protocol support
- `lambda-execution-policy.json` - IAM policy for Lambda execution role
- `lambda-trust-policy.json` - Trust policy for Lambda execution role
- `requirements.txt` - Python dependencies (boto3 is included in Lambda runtime)

## Deployment Instructions

### Option 1: AWS Console Deployment

1. **Create the Lambda Function:**
   ```
   - Go to AWS Lambda Console
   - Click "Create function"
   - Choose "Author from scratch"
   - Function name: a208194-mcp-application-details
   - Runtime: Python 3.9 or 3.11
   - Architecture: x86_64
   ```

2. **Upload the Code:**
   ```
   - Upload the ZIP file containing lambda_function.py
   - Or copy-paste the code from lambda_function.py into the inline editor
   ```

3. **Set Configuration:**
   ```
   - Handler: lambda_function.lambda_handler
   - Timeout: 30 seconds
   - Memory: 128 MB (increase if needed for your data source)
   ```

4. **Configure Execution Role:**
   ```
   - Create a new role or use existing role
   - Attach policies based on lambda-execution-policy.json
   - Ensure it has basic Lambda execution permissions
   ```

### Option 2: AWS CLI Deployment

1. **Create Execution Role:**
   ```bash
   # Create the role
   aws iam create-role \
     --role-name a208194-mcp-app-details-role \
     --assume-role-policy-document file://lambda-trust-policy.json

   # Attach basic Lambda execution policy
   aws iam attach-role-policy \
     --role-name a208194-mcp-app-details-role \
     --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

   # Attach custom policy for data access
   aws iam put-role-policy \
     --role-name a208194-mcp-app-details-role \
     --policy-name DataAccessPolicy \
     --policy-document file://lambda-execution-policy.json
   ```

2. **Create Lambda Function:**
   ```bash
   # Create ZIP package
   zip -r mcp-app-details.zip lambda_function.py

   # Create function
   aws lambda create-function \
     --function-name a208194-mcp-application-details \
     --runtime python3.11 \
     --role arn:aws:iam::818565325759:role/a208194-mcp-app-details-role \
     --handler lambda_function.lambda_handler \
     --zip-file fileb://mcp-app-details.zip \
     --timeout 30 \
     --memory-size 128
   ```

### Option 3: CloudFormation Template

```yaml
Resources:
  ApplicationDetailsLambda:
    Type: AWS::Lambda::Function
    Properties:
      FunctionName: a208194-mcp-application-details
      Runtime: python3.11
      Handler: lambda_function.lambda_handler
      Code:
        ZipFile: |
          # Paste the content of lambda_function.py here
      Role: !GetAtt LambdaExecutionRole.Arn
      Timeout: 30
      MemorySize: 128

  LambdaExecutionRole:
    Type: AWS::IAM::Role
    Properties:
      RoleName: a208194-mcp-app-details-role
      AssumeRolePolicyDocument:
        Version: '2012-10-17'
        Statement:
          - Effect: Allow
            Principal:
              Service: lambda.amazonaws.com
            Action: sts:AssumeRole
      ManagedPolicyArns:
        - arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole
      Policies:
        - PolicyName: DataAccessPolicy
          PolicyDocument:
            # Content from lambda-execution-policy.json
```

## Configuration Steps

### 1. Update Data Source
Edit the `get_application_from_data_source()` function in `lambda_function.py` to connect to your actual data source:

- **DynamoDB**: Uncomment the DynamoDB example and set table name
- **RDS**: Add database connection logic
- **API**: Add external API calls
- **S3**: Add S3 object retrieval
- **Parameter Store**: Add SSM parameter retrieval

### 2. Set Environment Variables
Add these environment variables in Lambda configuration:
```
APPLICATIONS_TABLE=your-dynamodb-table-name
DATABASE_HOST=your-rds-endpoint
API_BASE_URL=your-api-endpoint
CONFIG_BUCKET=your-s3-bucket
```

### 3. Test the Function
Test with MCP protocol payload:
```json
{
  "method": "tools/call",
  "id": 1,
  "params": {
    "name": "get_application_details",
    "arguments": {
      "asset_id": "a123456"
    }
  }
}
```

## Integration with Agent Core Gateway

After deploying the Lambda function, update your gateway configuration:

1. **Get the Lambda ARN:**
   ```bash
   aws lambda get-function --function-name a208194-mcp-application-details
   ```

2. **Update Gateway Target:**
   Use the ARN (e.g., `arn:aws:lambda:us-east-1:818565325759:function:a208194-mcp-application-details`) in your gateway configuration.

3. **Update Gateway Permissions:**
   Ensure the gateway service role can invoke the new Lambda function.

## Troubleshooting

### Common Issues:

1. **Permission Errors:**
   - Check Lambda execution role has required permissions
   - Verify gateway service role can invoke Lambda

2. **Data Source Issues:**
   - Update the data source connection logic
   - Check network connectivity (VPC, security groups)
   - Verify credentials and access permissions

3. **MCP Format Issues:**
   - Ensure responses follow MCP content format
   - Check JSON-RPC 2.0 compliance

### Testing:

1. **Direct Lambda Test:**
   Test with both MCP and direct invocation payloads

2. **Gateway Test:**
   Use the gateway endpoint to test integration

3. **End-to-End Test:**
   Test with actual client applications

## Notes

- This Lambda is backward compatible with direct invocation
- Mock data is included for testing - replace with your actual data source
- Function supports both MCP protocol and traditional Lambda invocation
- Error handling returns proper MCP format for gateway integration
- Function name follows your existing naming convention (a208194-prefix)